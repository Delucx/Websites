package ph.pup.itech.raven.controller;

import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import ph.pup.itech.raven.dao.RegisterDao;
import ph.pup.itech.raven.model.RegisterModel;

@WebServlet(name = "userM", urlPatterns = {"/User"})
public class userM extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RegisterDao employee = new RegisterDao();
        ArrayList<RegisterModel> employeeList = employee.getemployeeList();
        request.setAttribute("employeeList", employeeList);
        RequestDispatcher rd = getServletContext().getRequestDispatcher(
                "/userManagement2.jsp");
        rd.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }
}
