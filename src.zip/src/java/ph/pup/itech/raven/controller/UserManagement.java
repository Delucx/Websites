package ph.pup.itech.raven.controller;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import ph.pup.itech.raven.model.UserManagementModel;
import ph.pup.itech.raven.dao.UserManagementDao;

public class UserManagement extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {  
        String action = request.getServletPath();
        switch (action) {
            case "/usermanagement":
                getUser(request, response);
                break;
            default:
                showUserForm(request, response);
                break;
        }        
       
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }     
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
    
    private void getUser(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String userName,description, userRole, loginStatus, accountStatus, message;
        int userId;
        
        userId = Integer.parseInt(request.getParameter("userId"));
        userName = request.getParameter("firstName");
        description = "I am groot";
        userRole = request.getParameter("userRole");
        loginStatus = "Offline";
        accountStatus =  "Offline";
        message = "Your " + userId + " has been added!";                      
        
        UserManagementModel userManagement = new UserManagementModel(userId, userName, description, userRole, loginStatus, accountStatus);
        UserManagementDao userDao = new UserManagementDao();
        UserManagementModel getusermanagementDetails = (UserManagementModel) userDao.getusermanagementDetails(userManagement);
        request.setAttribute("user", getusermanagementDetails);
        request.setAttribute("message", message);
        RequestDispatcher rd = getServletContext().getRequestDispatcher(
                "/userManagement2.jsp");
        rd.forward(request, response);
    }

    private void showUserForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher rd = getServletContext().getRequestDispatcher(
                "/userManagement2.jsp");
        rd.forward(request, response);
    }        
}
