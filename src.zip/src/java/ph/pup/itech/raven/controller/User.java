package ph.pup.itech.raven.controller;

import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import ph.pup.itech.raven.model.UserModel;
import ph.pup.itech.raven.dao.UserDao;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.DriverManager;

public class User extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getServletPath();
        switch (action) {
//            case "/Register/Create/Form":
//                showEmployeeCreateForm(request, response);
//                break;
//            case "/Register/Login":
//                createEmployee(request, response);
////                viewList(request, response);
//                break;
//            case "":
//                viewloginForm(request, response);
//                break;
//            case "/Home":
//                activate(request, response);
//                break;
//            case "/Register/Login/Form":
//                loginForm(request, response);
//                break;
            case "/Product/Update/Form":
                showEmployeeUpdateForm(request, response);
                break;
            case "/Product/Updated":
                updateEmployee(request, response);
                break;
            case "/Product/Delete":
                deleteEmployee(request, response);
                break;
            default:
                viewEmployee(request, response);
                break;
        }     
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
    
    private void viewEmployee(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        UserDao product = new UserDao();
        ArrayList<UserModel> productList = product.getproductList();
        request.setAttribute("productList", productList);
        request.setAttribute("status", "success");
        RequestDispatcher rd = getServletContext().getRequestDispatcher(
                "/product2.jsp");
        rd.forward(request, response);
    }

    private void showEmployeeUpdateForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int productId = Integer.parseInt(request.getParameter("productId"));
        UserDao employee = new UserDao();
        UserModel employeeDetails = employee.getProductDetails(productId);
        request.setAttribute("employeeDetails", employeeDetails);
        RequestDispatcher rd = getServletContext().getRequestDispatcher(
                "/productUpdate.jsp");
        rd.forward(request, response);
    }

    private void updateEmployee(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int productId = Integer.parseInt(request.getParameter("productId"));
        String productName = request.getParameter("productName");
        String description = request.getParameter("description");
        String size = request.getParameter("size");
        Double price = Double.parseDouble(request.getParameter("price"));
        int quantity = Integer.parseInt(request.getParameter("quantity"));


        RequestDispatcher dispatcher = null;
        Connection conn = null;
        try {
            String driver = "com.mysql.cj.jdbc.Driver";
            Class.forName(driver);

            String url = "jdbc:mysql://localhost:3306/test1?serverTimezone=UTC";
            conn = (Connection) DriverManager.getConnection(url, "root", "@Kingjulius12421");           

            PreparedStatement ps = conn.prepareStatement("UPDATE product SET "
                    + "productname = ?, "
                    + "description = ?, "
                    + "size = ?, "
                    + "price = ?, "
                    + "quantity = ? "
                    + "WHERE productId = ?");
            ps.setString(1, productName);
            ps.setString(2, description);
            ps.setString(3, size);
            ps.setDouble(4, price);
            ps.setInt(5, quantity);
            ps.setInt(6, productId);

            int rowAffected = ps.executeUpdate();
            dispatcher = request.getRequestDispatcher("/productUpdate.jsp");
            if (rowAffected != 0) {
                request.setAttribute("status", "success");
            } else {
                request.setAttribute("status", "failed");
            }
            dispatcher.forward(request, response);
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
        
    private void deleteEmployee(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int productId = Integer.parseInt(request.getParameter("productId"));

        UserDao employee = new UserDao();
        employee.deleteEmployee(productId);

        

        response.sendRedirect(request.getContextPath() + "/Product");
    
    }        
}
