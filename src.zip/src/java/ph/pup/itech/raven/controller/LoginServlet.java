package ph.pup.itech.raven.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpSession;
import java.sql.SQLException;
import com.lambdaworks.crypto.SCryptUtil;

@WebServlet(name = "LoginServlet", urlPatterns = {"/Login"})
public class LoginServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher rd = getServletContext().getRequestDispatcher("/home2.jsp");
        rd.forward (request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String usernameField = request.getParameter("username");
        String password = request.getParameter("password");
        HttpSession session = request.getSession();
        RequestDispatcher dispatcher = null;
        Connection conn = null;
        try {
            String driver = "com.mysql.cj.jdbc.Driver";
            Class.forName(driver);
            String url = "jdbc:mysql://localhost:3306/test1?serverTimezone=UTC";
            conn = (Connection) DriverManager.getConnection(url, "root", "@Kingjulius12421");

            PreparedStatement ps = conn.prepareStatement("select * from employee where usernameField = ?");
            ps.setString(1, usernameField);

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                String encryptedPassword = rs.getString("encryptedPassword");
                if (SCryptUtil.check(password, encryptedPassword)) {
                    session.setAttribute("username", usernameField);

                    // Update login status to "online"
                    updateLoginStatus(usernameField, true, conn);

                    dispatcher = request.getRequestDispatcher("index.jsp");
                } else {
                    request.setAttribute("status", "failed");
                    dispatcher = request.getRequestDispatcher("Preview");
                }
            } else {
                request.setAttribute("status", "failed");
                dispatcher = request.getRequestDispatcher("Preview");
            }
            dispatcher.forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void updateLoginStatus(String username, boolean isOnline, Connection conn) {
        try {
            PreparedStatement ps = conn.prepareStatement("UPDATE employee SET loginStatus = ? WHERE usernameField = ?");
            ps.setString(1, isOnline ? "online" : "offline");
            ps.setString(2, username);
            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Login status updated successfully for user: " + username);
            } else {
                System.out.println("No rows updated for user: " + username);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
