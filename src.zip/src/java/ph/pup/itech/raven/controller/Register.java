package ph.pup.itech.raven.controller;

import com.lambdaworks.crypto.SCryptUtil;
import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import ph.pup.itech.raven.model.RegisterModel;
import ph.pup.itech.raven.dao.RegisterDao;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.DriverManager;
import java.sql.ResultSet;

public class Register extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getServletPath();
        switch (action) {
            case "/Register/Create/Form":
                showEmployeeCreateForm(request, response);
                break;
            case "/Register/Login":
                createEmployee(request, response);
                break;
            case "/UserManagement/Update/Form":
                showEmployeeUpdateForm(request, response);
                break;
            case "/UserManagement/Updated":
                updateEmployee(request, response);
                break;
            case "/UserManagement/Delete":
                deleteEmployee(request, response);
                break;
            default:
                viewEmployee(request, response);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    private void viewEmployee(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RegisterDao employee = new RegisterDao();
        ArrayList<RegisterModel> employeeList = employee.getemployeeList();
        request.setAttribute("employeeList", employeeList);
        request.setAttribute("status", "success");
        RequestDispatcher rd = getServletContext().getRequestDispatcher(
                "/userManagement2.jsp");
        rd.forward(request, response);
    }

    private void showEmployeeCreateForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        RequestDispatcher rd = getServletContext().getRequestDispatcher(
                "/form.jsp");
        rd.forward(request, response);
    }

    private void createEmployee(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String usernameField, passwordField, firstNameField, middleNameField, lastNameField, addressField;
        String birthdateField, phoneNumberField;

        int idField = Integer.parseInt(request.getParameter("idField"));
        usernameField = request.getParameter("usernameField");
        passwordField = request.getParameter("passwordField");
        firstNameField = request.getParameter("firstNameField");
        middleNameField = request.getParameter("middleNameField");
        lastNameField = request.getParameter("lastNameField");
        addressField = request.getParameter("addressField");
        birthdateField = request.getParameter("birthdateField");
        phoneNumberField = request.getParameter("phoneNumberField");
        String loginStatus = request.getParameter("loginStatus");

        RegisterDao employee = new RegisterDao();
        RegisterModel createEmployee = new RegisterModel(idField, usernameField, passwordField, firstNameField, middleNameField, lastNameField, addressField, birthdateField, phoneNumberField, loginStatus);
        employee.createEmployee(createEmployee);
        response.sendRedirect(request.getContextPath() + "/Login");

        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void showEmployeeUpdateForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int idField = Integer.parseInt(request.getParameter("idField"));
        RegisterDao employee = new RegisterDao();
        RegisterModel employeeDetails = employee.getEmployeeDetails(idField);
        request.setAttribute("employeeDetails", employeeDetails);
        RequestDispatcher rd = getServletContext().getRequestDispatcher(
                "/userUpdate.jsp");
        rd.forward(request, response);
    }

    private void updateEmployee(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String usernameField, passwordField, firstNameField, middleNameField, lastNameField, addressField;
        String birthdateField, phoneNumberField;

        int idField = Integer.parseInt(request.getParameter("idField"));
        usernameField = request.getParameter("usernameField");
        passwordField = request.getParameter("passwordField");
        firstNameField = request.getParameter("firstNameField");
        middleNameField = request.getParameter("middleNameField");
        lastNameField = request.getParameter("lastNameField");
        addressField = request.getParameter("addressField");
        birthdateField = request.getParameter("birthdateField");
        phoneNumberField = request.getParameter("phoneNumberField");
        String loginStatus = request.getParameter("loginStatus");

        String encryptedPassword = SCryptUtil.scrypt(passwordField, 16, 16, 16);

        RequestDispatcher dispatcher = null;
        Connection conn = null;
        try {
            String driver = "com.mysql.cj.jdbc.Driver";
            Class.forName(driver);

            String url = "jdbc:mysql://localhost:3306/test1?serverTimezone=UTC";
            conn = (Connection) DriverManager.getConnection(url, "root", "@Kingjulius12421");

            // Retrieve the previous encrypted password
            PreparedStatement selectPs = conn.prepareStatement("SELECT encryptedPassword FROM employee WHERE idField = ?");
            selectPs.setInt(1, idField);
            ResultSet resultSet = selectPs.executeQuery();
            String previousEncryptedPassword = null;
            if (resultSet.next()) {
                previousEncryptedPassword = resultSet.getString("encryptedPassword");
            }

            // Check if the new password is the same as the previous password
            if (previousEncryptedPassword != null && SCryptUtil.check(passwordField, previousEncryptedPassword)) {
                request.setAttribute("status", "failed");
                dispatcher = request.getRequestDispatcher("/userUpdate.jsp");
                dispatcher.forward(request, response);
                return; // Stop further execution
            }

            PreparedStatement ps = conn.prepareStatement("UPDATE employee SET "
                    + "usernameField = ?, "
                    + "encryptedPassword = ?, "
                    + "firstNameField = ?, "
                    + "middleNameField = ?, "
                    + "lastNameField = ?, "
                    + "addressField = ?, "
                    + "birthDateField = ?, "
                    + "phoneNumberField = ?, "
                    + "loginStatus = ? "
                    + "WHERE idField = ?");
            ps.setString(1, usernameField);
            ps.setString(2, encryptedPassword);
            ps.setString(3, firstNameField);
            ps.setString(4, middleNameField);
            ps.setString(5, lastNameField);
            ps.setString(6, addressField);
            ps.setString(7, birthdateField);
            ps.setString(8, phoneNumberField);
            ps.setString(9, loginStatus);
            ps.setInt(10, idField);

            int rowAffected = ps.executeUpdate();
            dispatcher = request.getRequestDispatcher("/userUpdate.jsp");
            if (rowAffected != 0) {
                request.setAttribute("status", "success");
            } else {
                request.setAttribute("status", "failed");
            }
            dispatcher.forward(request, response);
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
        
    private void deleteEmployee(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int idField = Integer.parseInt(request.getParameter("idField"));

        RegisterDao employee = new RegisterDao();
        employee.deleteEmployee(idField);

        response.sendRedirect(request.getContextPath() + "/UserManagement");
    
    }
}
