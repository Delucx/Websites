package ph.pup.itech.raven.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import javax.servlet.RequestDispatcher;
import com.lambdaworks.crypto.SCryptUtil;

@WebServlet(name = "UserFormServlet", urlPatterns = {"/UserForm"})
public class UserFormServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher rd = getServletContext().getRequestDispatcher("/userForm2.jsp");
        rd. forward (request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int idField = Integer.parseInt(request.getParameter("userId"));
        String usernameField = request.getParameter("usernameField");
        String passwordField = request.getParameter("passwordField");
        String firstNameField = request.getParameter("firstName");
        String middleNameField = request.getParameter("middleName");
        String lastNameField = request.getParameter("lastName");
        String addressField = request.getParameter("addressField");
        String birthdateField = request.getParameter("birthdateField");
        String phoneNumberField = request.getParameter("phoneNumberField");
        String accountStatus = "Valid";
        String loginStatus = "offline";
        String userRole = request.getParameter("userRole");

        String encryptedPassword = SCryptUtil.scrypt(passwordField, 16, 16, 16);

        RequestDispatcher dispatcher = null;
        Connection conn = null;
        try {
            String driver = "com.mysql.cj.jdbc.Driver";
            Class.forName(driver);
            String url = "jdbc:mysql://localhost:3306/test1?serverTimezone=UTC";
            conn = (Connection) DriverManager.getConnection(url, "root", "@Kingjulius12421");
            PreparedStatement ps = conn.prepareStatement("insert into employee ("
                    + "idField, "
                    + "usernameField, "
                    + "encryptedPassword, "
                    + "firstNameField, "
                    + "middleNameField, "
                    + "lastNameField, "
                    + "addressField, "
                    + "birthDateField, "
                    + "phoneNumberField, "
                    + "accountStatus, "
                    + "loginStatus, "
                    + "userRole) "
                    + "values (?,?,?,?,?,?,?,?,?,?,?,?)");
            ps.setInt(1, idField);
            ps.setString(2, usernameField);
            ps.setString(3, encryptedPassword);
            ps.setString(4, firstNameField);
            ps.setString(5, middleNameField);
            ps.setString(6, lastNameField);
            ps.setString(7, addressField);
            ps.setString(8, birthdateField);
            ps.setString(9, phoneNumberField);
            ps.setString(10, accountStatus);
            ps.setString(11, loginStatus);
            ps.setString(12, userRole);
            int rowAffected = ps.executeUpdate();
            dispatcher = request.getRequestDispatcher("userForm2.jsp");
            if (rowAffected != 0) {
                request.setAttribute("status", "success");

            } else {
                request.setAttribute("status", "failed");
            }
            dispatcher.forward(request, response);

        } catch (SQLException e) {
            // Handle the duplicate ID error
            if (e.getErrorCode() == 1062) { // MySQL error code for duplicate entry
                request.setAttribute("status", "failed");
                dispatcher = request.getRequestDispatcher("userForm2.jsp");
                dispatcher.forward(request, response);
            } else {
                System.out.println("SQLException: " + e.getMessage());
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}

