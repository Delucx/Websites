package ph.pup.itech.raven.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import javax.servlet.RequestDispatcher;
import com.lambdaworks.crypto.SCryptUtil;

@WebServlet(name = "RegistrationServlet", urlPatterns = {"/Registration"})
public class RegistrationServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String usernameField, passwordField, firstNameField, middleNameField, lastNameField, addressField;
        String birthdateField, phoneNumberField;

        int idField = Integer.parseInt(request.getParameter("idField"));
        usernameField = request.getParameter("usernameField");
        passwordField = request.getParameter("passwordField");
        firstNameField = request.getParameter("firstNameField");
        middleNameField = request.getParameter("middleNameField");
        lastNameField = request.getParameter("lastNameField");
        addressField = request.getParameter("addressField");
        birthdateField = request.getParameter("birthdateField");
        phoneNumberField = request.getParameter("phoneNumberField");
        String accountStatus = "Valid";
        String loginStatus = "offline";
        String userRole = "Administrator";
        
        String encryptedPassword = SCryptUtil.scrypt(passwordField, 16, 16, 16);
        
        RequestDispatcher dispatcher = null;
        Connection conn = null;
        try {
            String driver = "com.mysql.cj.jdbc.Driver";
            Class.forName(driver);
            String url = "jdbc:mysql://localhost:3306/test1?serverTimezone=UTC";
            conn = (Connection) DriverManager.getConnection(url, "root", "@Kingjulius12421");
            PreparedStatement ps = conn.prepareStatement("insert into employee ("
                    + "idField, "
                    + "usernameField, "
                    + "encryptedPassword, "
                    + "firstNameField, "
                    + "middleNameField, "
                    + "lastNameField, "
                    + "addressField, "
                    + "birthDateField, "
                    + "phoneNumberField, "
                    + "accountStatus, "
                    + "loginStatus, "
                    + "userRole) "
                    + "values (?,?,?,?,?,?,?,?,?,?,?,?)");
            ps.setInt(1, idField);
            ps.setString(2, usernameField);
            ps.setString(3, encryptedPassword);
            ps.setString(4, firstNameField);
            ps.setString(5, middleNameField);
            ps.setString(6, lastNameField);
            ps.setString(7, addressField);
            ps.setString(8, birthdateField);
            ps.setString(9, phoneNumberField);
            ps.setString(10,accountStatus);
            ps.setString(11,loginStatus);
            ps.setString(12,userRole);
            int rowAffected = ps.executeUpdate();
            dispatcher = request.getRequestDispatcher("form.jsp");
            if (rowAffected != 0) {
                request.setAttribute("status", "success");

            } else {
                request.setAttribute("status", "failed");
            }
            dispatcher.forward(request, response);

        } catch (SQLException e) {
            // Handle the duplicate ID error
            if (e.getErrorCode() == 1062) { // MySQL error code for duplicate entry
                request.setAttribute("status", "failed");
                dispatcher = request.getRequestDispatcher("form.jsp");
                dispatcher.forward(request, response);
            } else {
                System.out.println("SQLException: " + e.getMessage());
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
