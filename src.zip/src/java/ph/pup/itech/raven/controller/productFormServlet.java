package ph.pup.itech.raven.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import javax.servlet.RequestDispatcher;

@WebServlet(name = "productFormServlet", urlPatterns = {"/productForm"})
public class productFormServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher rd = getServletContext().getRequestDispatcher("/productForm2.jsp");
        rd. forward (request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int productId = Integer.parseInt(request.getParameter("productId"));
        String productName = request.getParameter("productName");
        String description = request.getParameter("description");
        String size = request.getParameter("size");
        double price = Double.parseDouble(request.getParameter("price"));
        int quantity = Integer.parseInt(request.getParameter("quantity"));

        RequestDispatcher dispatcher = null;
        Connection conn = null;
        try {
            String driver = "com.mysql.cj.jdbc.Driver";
            Class.forName(driver);
            String url = "jdbc:mysql://localhost:3306/test1?serverTimezone=UTC";
            conn = (Connection) DriverManager.getConnection(url, "root", "@Kingjulius12421");
            PreparedStatement ps = conn.prepareStatement("insert into product ("
                    + "productId, "
                    + "productName, "
                    + "description, "
                    + "size, "
                    + "price, "
                    + "quantity) "
                    + "values (?,?,?,?,?,?)");
            ps.setInt(1, productId);
            ps.setString(2, productName);
            ps.setString(3, description);
            ps.setString(4, size);
            ps.setDouble(5, price);
            ps.setInt(6, quantity);

            int rowAffected = ps.executeUpdate();
            dispatcher = request.getRequestDispatcher("productForm2.jsp");
            if (rowAffected != 0) {
                request.setAttribute("status", "success");

            } else {
                request.setAttribute("status", "failed");
            }
            dispatcher.forward(request, response);

        } catch (SQLException e) {
            // Handle the duplicate ID error
            if (e.getErrorCode() == 1062) { // MySQL error code for duplicate entry
                request.setAttribute("status", "failed");
                dispatcher = request.getRequestDispatcher("productForm2.jsp");
                dispatcher.forward(request, response);
            } else {
                System.out.println("SQLException: " + e.getMessage());
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
