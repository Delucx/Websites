/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package ph.pup.itech.raven.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

@WebServlet(name = "Logout", urlPatterns = {"/Logout"})
public class Logout extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        String username = (String) session.getAttribute("username");

        // Update login status to "offline" when user logs out
        if (username != null) {
            Connection conn = null;
            try {
                String driver = "com.mysql.cj.jdbc.Driver";
                Class.forName(driver);
                String url = "jdbc:mysql://localhost:3306/test1?serverTimezone=UTC";
                conn = (Connection) DriverManager.getConnection(url, "root", "@Kingjulius12421");

                updateLoginStatus(username, false, conn);
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                try {
                    if (conn != null) {
                        conn.close();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        // Clear session attributes and invalidate session
        session.removeAttribute("username");
        session.removeAttribute("idField");
        session.invalidate();

        // Redirect to login page or any other appropriate page
        response.sendRedirect(request.getContextPath() + "/Preview");
    }
    
    
    private void updateLoginStatus(String username, boolean isOnline, Connection conn) throws Exception {
        PreparedStatement ps = conn.prepareStatement("UPDATE employee SET loginStatus = ? WHERE usernameField = ?");
        ps.setString(1, isOnline ? "online" : "offline");
        ps.setString(2, username);
        ps.executeUpdate();
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }
}
