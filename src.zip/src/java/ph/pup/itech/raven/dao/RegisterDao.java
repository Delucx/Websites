package ph.pup.itech.raven.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import ph.pup.itech.raven.model.RegisterModel;

public class RegisterDao {
    
    public ArrayList<RegisterModel> getemployeeList() {
        ArrayList<RegisterModel> employeeList = new ArrayList<>();
        Connection conn  = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "select * from employee";
        try {
            conn = ConnectionPool.getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                RegisterModel user = new RegisterModel();
                user.setidField(rs.getInt("idField"));
                user.setusernameField(rs.getString("usernameField"));
                user.setencryptedPassword(rs.getString("encryptedPassword"));
                user.setfirstNameField(rs.getString("firstNameField"));
                user.setmiddleNameField(rs.getString("middleNameField"));
                user.setlastNameField(rs.getString("lastNameField"));
                user.setaddressField(rs.getString("addressField"));
                user.setbirthdateField(rs.getString("birthDateField"));
                user.setphoneNumberField(rs.getString("phoneNumberField"));
                user.setaccountStatus(rs.getString("accountStatus"));
                user.setloginStatus(rs.getString("loginStatus"));
                user.setuserRole(rs.getString("userRole"));
                employeeList.add(user);
            }
            
            conn.close();
        } catch (SQLException e) {
            System.out.println("getEmployeeList Error: " + e); 
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    //ignore
                }
            }
            if (ps != null) {
                try {
                    ps.close();
                } catch (SQLException e) {
                    //ignore
                }
            }
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    //ignore
                }
            }
            
        }
        return employeeList;
    }   
    
    public RegisterModel getEmployeeDetails(int idField) {
        RegisterModel employeeDetails = null;
        Connection conn  = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = ""
                + "select idField, "
                + "usernameField, "
                + "encryptedPassword, "
                + "firstNameField, "
                + "middleNameField, "
                + "lastNameField, "
                + "addressField, "
                + "birthDateField, "
                + "phoneNumberField, "
                + "accountStatus, "
                + "loginStatus, "
                + "userRole "
                + "from employee "
                + "where idField = ? ";
        try {
            conn = ConnectionPool.getConnection();
            ps = conn.prepareStatement(query);
            ps.setInt(1, idField);
            rs = ps.executeQuery();
            if (rs.next()) {
                idField = rs.getInt("idField");
                String usernameField = rs.getString("usernameField");
                String encryptedPassword = rs.getString("encryptedPassword");
                String firstNameField = rs.getString("firstNameField");
                String middleNameField = rs.getString("middleNameField");
                String lastNameField = rs.getString("lastNameField");
                String addressField = rs.getString("addressField");
                String birthdateField = rs.getString("birthDateField");
                String phoneNumberField = rs.getString("phoneNumberField");
                String accountStatus = rs.getString("accountStatus");
                String loginStatus = rs.getString("loginStatus");
                String userRole = rs.getString("userRole");
                employeeDetails = new RegisterModel(idField, usernameField, encryptedPassword, firstNameField, middleNameField, lastNameField, addressField, birthdateField, phoneNumberField, accountStatus, loginStatus, userRole);
                
            }
        } catch (SQLException e) {
            System.out.println("getEmployeeDetails Error: " + e); 
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    //ignore
                }
            }
            if (ps != null) {
                try {
                    ps.close();
                } catch (SQLException e) {
                    //ignore
                }
            }
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    //ignore
                }
            }
            
        }
        return employeeDetails;
    }
    
    public boolean createEmployee(RegisterModel employee) {
        boolean success = false;
        Connection conn  = null;
        PreparedStatement ps = null;
        String query = "insert into employee ("
                + "idField, "
                + "usernameField, "
                + "encryptedPassword, "
                + "firstNameField, "
                + "middleNameField, "
                + "lastNameField, "
                + "addressField, "
                + "birthDateField, "
                + "phoneNumberField, "
                + "loginStatus) "
                + "values (?,?,?,?,?,?,?,?,?,?)";
        try {
            conn = ConnectionPool.getConnection();
            ps = conn.prepareStatement(query);
            ps.setInt(1, employee.getidField());
            ps.setString(2, employee.getusernameField());
            ps.setString(3, employee.getencryptedPassword());
            ps.setString(4, employee.getfirstNameField());
            ps.setString(5, employee.getmiddleNameField());
            ps.setString(6, employee.getlastNameField());
            ps.setString(7, employee.getaddressField());
            ps.setString(8, employee.getbirthdateField());
            ps.setString(9, employee.getphoneNumberField());
            ps.setString(10,employee.getloginStatus());
            int rowAffected = ps.executeUpdate();
            if (rowAffected != 0) {
                success = true;
            }
        } catch (SQLException e) {
            System.out.println("createEmployee Error: " + e); 
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    //ignore
                }
            }
            if (ps != null) {
                try {
                    ps.close();
                } catch (SQLException e) {
                    //ignore
                }
            }
            
        }
        return success;
    }
    
    public boolean updateEmployee(RegisterModel employee) {
        boolean success = false;
        Connection conn  = null;
        PreparedStatement ps = null;
        String query = "update employee set "
                + "usernameField = ?, "
                + "encryptedPassword = ?, "
                + "firstNameField= ?, "
                + "middleNameField = ?, "
                + "lastNameField = ?, "
                + "addressField = ?, "
                + "birthDateField = ?, "
                + "phoneNumberField = ?, "
                + "loginStatus = ? "
                + "where idField = ? ";
        try {
            conn = ConnectionPool.getConnection();
            ps = conn.prepareStatement(query);
            ps.setInt(10, employee.getidField());
            ps.setString(1, employee.getusernameField());
            ps.setString(2, employee.getencryptedPassword());
            ps.setString(3, employee.getfirstNameField());
            ps.setString(4, employee.getmiddleNameField());
            ps.setString(5, employee.getlastNameField());
            ps.setString(6, employee.getaddressField());
            ps.setString(7, employee.getbirthdateField());
            ps.setString(8, employee.getphoneNumberField());
            ps.setString(9,employee.getloginStatus());
            int rowAffected = ps.executeUpdate();
            if (rowAffected != 0) {
                success = true;
            }
        } catch (SQLException e) {
            System.out.println("updateEmployee Error: " + e); 
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    //ignore
                }
            }
            if (ps != null) {
                try {
                    ps.close();
                } catch (SQLException e) {
                    //ignore
                }
            }
            
        }
        return success;
    }
    
    public boolean deleteEmployee(int idField) {
        boolean success = false;
        Connection conn  = null;
        PreparedStatement ps = null;
        String query = "delete from employee "
                + "where idField = ? ";
        try {
            conn = ConnectionPool.getConnection();
            ps = conn.prepareStatement(query);
            ps.setInt(1, idField);
            int rowAffected = ps.executeUpdate();
            if (rowAffected != 0) {
                success = true;
            }
        } catch (SQLException e) {
            System.out.println("deleteEmployee Error: " + e); 
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    //ignore
                }
            }
            if (ps != null) {
                try {
                    ps.close();
                } catch (SQLException e) {
                    //ignore
                }
            }
            
        }
        return success;
    }
}
