package ph.pup.itech.raven.dao;

import ph.pup.itech.raven.model.UserManagementModel;

public class UserManagementDao {
    public UserManagementModel getusermanagementDetails(UserManagementModel userManagement) {
        UserManagementModel usermanagementDetails;
        int userId = userManagement.getuserId();
        String userName = userManagement.getuserName();
        String description = userManagement.getDescription();
        String userRole = userManagement.getuserRole();
        String loginStatus = userManagement.getloginStatus();
        String accountStatus = userManagement.getaccountStatus();
        usermanagementDetails = new UserManagementModel (userId, userName, description, userRole, loginStatus, accountStatus);
        System.out.println("User Details: " + usermanagementDetails);
        return usermanagementDetails;
    }
    
    public String getuserId() {
        String userId = null;
        return userId;
    }
}
