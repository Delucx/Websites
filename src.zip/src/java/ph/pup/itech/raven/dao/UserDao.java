package ph.pup.itech.raven.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import ph.pup.itech.raven.model.UserModel;

public class UserDao {
    public ArrayList<UserModel> getproductList() {
        ArrayList<UserModel> productList = new ArrayList<>();
        Connection conn  = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "select * from product";
        try {
            conn = ConnectionPool.getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                UserModel product = new UserModel();
                product.setProductId(rs.getInt("productId"));
                product.setProductName(rs.getString("productName"));
                product.setDescription(rs.getString("description"));
                product.setSize(rs.getString("size"));
                product.setPrice(rs.getDouble("price"));
                product.setQuantity(rs.getInt("quantity"));
                productList.add(product);
            }
            
            conn.close();
        } catch (SQLException e) {
            System.out.println("getProductList Error: " + e); 
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    //ignore
                }
            }
            if (ps != null) {
                try {
                    ps.close();
                } catch (SQLException e) {
                    //ignore
                }
            }
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    //ignore
                }
            }
            
        }
        return productList;
    }   
    
    public UserModel getProductDetails(int productId) {
        UserModel productDetails = null;
        Connection conn  = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = ""
                + "select productId, "
                + "productName, "
                + "desciption, "
                + "size, "
                + "price, "
                + "quantity "
                + "from product "
                + "where productId = ? ";
        try {
            conn = ConnectionPool.getConnection();
            ps = conn.prepareStatement(query);
            ps.setInt(1, productId);
            rs = ps.executeQuery();
            if (rs.next()) {
                productId = rs.getInt("productId");
                String productName= rs.getString("productName");
                String description = rs.getString("description");
                String size = rs.getString("size");
                Double price = rs.getDouble("price");
                int quantity = rs.getInt("quantity");

                productDetails = new UserModel(productId, productName, description, size, price, quantity);
                
            }
        } catch (SQLException e) {
            System.out.println("getProductDetails Error: " + e); 
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    //ignore
                }
            }
            if (ps != null) {
                try {
                    ps.close();
                } catch (SQLException e) {
                    //ignore
                }
            }
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    //ignore
                }
            }
            
        }
        return productDetails;
    }    
    
    public boolean updateEmployee(UserModel employee) {
        boolean success = false;
        Connection conn  = null;
        PreparedStatement ps = null;
        String query = "update product set "
                + "productName = ?, "
                + "description = ?, "
                + "size = ?, "
                + "price = ?, "
                + "quantity = ? "
                + "where productId = ? ";
        try {
            conn = ConnectionPool.getConnection();
            ps = conn.prepareStatement(query);
            ps.setInt(6, employee.getProductId());
            ps.setString(1, employee.getProductName());
            ps.setString(2, employee.getDescription());
            ps.setString(3, employee.getSize());
            ps.setDouble(4, employee.getPrice());
            ps.setInt(5, employee.getQuantity());
            int rowAffected = ps.executeUpdate();
            if (rowAffected != 0) {
                success = true;
            }
        } catch (SQLException e) {
            System.out.println("updateEmployee Error: " + e); 
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    //ignore
                }
            }
            if (ps != null) {
                try {
                    ps.close();
                } catch (SQLException e) {
                    //ignore
                }
            }
            
        }
        return success;
    }
    
    public boolean deleteEmployee(int productId) {
        boolean success = false;
        Connection conn  = null;
        PreparedStatement ps = null;
        String query = "delete from product "
                + "where productId = ? ";
        try {
            conn = ConnectionPool.getConnection();
            ps = conn.prepareStatement(query);
            ps.setInt(1, productId);
            int rowAffected = ps.executeUpdate();
            if (rowAffected != 0) {
                success = true;
            }
        } catch (SQLException e) {
            System.out.println("deleteEmployee Error: " + e); 
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    //ignore
                }
            }
            if (ps != null) {
                try {
                    ps.close();
                } catch (SQLException e) {
                    //ignore
                }
            }
            
        }
        return success;
    }
}
