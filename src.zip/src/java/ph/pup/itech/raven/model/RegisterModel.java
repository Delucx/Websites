package ph.pup.itech.raven.model;

public class RegisterModel {
    private int idField;
    private String usernameField;
    private String encryptedPassword;
    private String firstNameField;
    private String middleNameField;
    private String lastNameField;
    private String addressField;
    private String birthdateField;
    private String phoneNumberField;
    private String accountStatus;
    private String loginStatus;
    private String userRole;
    
    public RegisterModel(){       
    }   
    
    public RegisterModel (String usernameField, String encryptedPassword) {
        this.usernameField = usernameField;
        this.encryptedPassword = encryptedPassword;     
    }
    
    public RegisterModel (int idField, String usernameField, String encryptedPassword) {
        this.idField = idField;
        this.usernameField = usernameField;
        this.encryptedPassword = encryptedPassword;     
    }
    
    public RegisterModel (int idField, String usernameField, String encryptedPassword, String firstNameField, String middleNameField, String lastNameField) {
        this.idField = idField;
        this.usernameField = usernameField;
        this.encryptedPassword = encryptedPassword;
        this.firstNameField = firstNameField;
        this.middleNameField = middleNameField;
        this.lastNameField = lastNameField;       
    }
    
    public RegisterModel (int idField, String usernameField, String encryptedPassword, String firstNameField, String middleNameField, String lastNameField, String addressField, String birthdateField, String phoneNumberField) {
        this.idField = idField;
        this.usernameField = usernameField;
        this.encryptedPassword = encryptedPassword;
        this.firstNameField = firstNameField;
        this.middleNameField = middleNameField;
        this.lastNameField = lastNameField;
        this.addressField = addressField;
        this.birthdateField = birthdateField;
        this.phoneNumberField = phoneNumberField;
    }
    
    public RegisterModel (int idField, String usernameField, String encryptedPassword, String firstNameField, String middleNameField, String lastNameField, String addressField, String birthdateField, String phoneNumberField, String loginStatus) {
        this.idField = idField;
        this.usernameField = usernameField;
        this.encryptedPassword = encryptedPassword;
        this.firstNameField = firstNameField;
        this.middleNameField = middleNameField;
        this.lastNameField = lastNameField;
        this.addressField = addressField;
        this.birthdateField = birthdateField;
        this.phoneNumberField = phoneNumberField;
        this.loginStatus = loginStatus;
    }  
    
    public RegisterModel (int idField, String usernameField, String encryptedPassword, String firstNameField, String middleNameField, String lastNameField, String addressField, String birthdateField, String phoneNumberField, String accountStatus, String loginStatus, String userRole) {
        this.idField = idField;
        this.usernameField = usernameField;
        this.encryptedPassword = encryptedPassword;
        this.firstNameField = firstNameField;
        this.middleNameField = middleNameField;
        this.lastNameField = lastNameField;
        this.addressField = addressField;
        this.birthdateField = birthdateField;
        this.phoneNumberField = phoneNumberField;
        this.accountStatus = accountStatus;
        this.loginStatus = loginStatus;
        this.userRole = userRole;
    }

    
    public int getidField() {
        return idField;
    }
    
    public void setidField(int idField) {
        this.idField = idField;
    }
    
    public String getusernameField() {
        return usernameField;
    }
    
    public void setusernameField(String usernameField) {
        this.usernameField = usernameField;
    }
    
    public String getencryptedPassword() {
        return encryptedPassword;
    }
    
    public void setencryptedPassword(String encryptedPassword) {
        this.encryptedPassword = encryptedPassword;
    }
    
    public String getfirstNameField() {
        return firstNameField;
    }
    
    public void setfirstNameField(String firstNameField) {
        this.firstNameField = firstNameField;
    }
    
    public String getmiddleNameField() {
        return middleNameField;
    }
    
    public void setmiddleNameField(String middleNameField) {
        this.middleNameField = middleNameField;
    }
    
    public String getlastNameField() {
        return lastNameField;
    }
    
    public void setlastNameField(String lastNameField) {
        this.lastNameField = lastNameField;
    }
    
    public String getaddressField() {
        return addressField;
    }
    
    public void setaddressField(String addressField) {
        this.addressField = addressField;
    }
    
    public String getbirthdateField() {
        return birthdateField;
    }
    
    public void setbirthdateField(String birthdateField) {
        this.birthdateField = birthdateField;
    }
    
    public String getphoneNumberField() {
        return phoneNumberField;
    }
    
    public void setphoneNumberField(String phoneNumberField) {
        this.phoneNumberField = phoneNumberField;
    }
    
    public String getaccountStatus() {
        return accountStatus;
    }
    
    public void setaccountStatus(String accountStatus) {
        this.accountStatus = accountStatus;
    }
    
    public String getloginStatus() {
        return loginStatus;
    }
    
    public void setloginStatus(String loginStatus) {
        this.loginStatus = loginStatus;
    }
    
    public String getuserRole() {
        return userRole;
    }
    
    public void setuserRole(String userRole) {
        this.userRole = userRole;
    }
}
