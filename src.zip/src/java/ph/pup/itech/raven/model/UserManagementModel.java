package ph.pup.itech.raven.model;

public class UserManagementModel {
    private int userId;
    private String userName;
    private String description;
    private String userRole;
    private String loginStatus;
    private String accountStatus;

    public UserManagementModel(int userId, String userName, String description, String userRole, String loginStatus, String accountStatus) {
        this.userId = userId;
        this.userName = userName;
        this.description = description;
        this.userRole = userRole;
        this.loginStatus = loginStatus;
        this.accountStatus = accountStatus;
    }
    public int getuserId() {
       return userId;
    }
    public void setuserId(int userId) {
        this.userId = userId;
    }
    
    public String getuserName() {
        return userName;
    }
    public void setuserName(String userName) {
        this.userName = userName;
    }
    
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    
    public String getuserRole() {
        return userRole;
    }
    public void setuserRole(String userRole) {
        this.userRole = userRole;
    }
    
    public String getloginStatus() {
         return loginStatus;
    }
    public void setloginStatus(String loginStatus) {
        this.loginStatus = loginStatus;
    }
    
    public String getaccountStatus() {
        return accountStatus;
    }
    public void setaccountStatus(String accountStatus) {
        this.accountStatus = accountStatus;
    }
}
